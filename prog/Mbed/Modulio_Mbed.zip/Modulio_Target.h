//-----------------------------
// Select Target device
//.............................
#define	PSOC1		0
#define	PIC24F08	0
#define	ATmega328	0
#define	RaspberryPi	0
#define	MBed		1
//-----------------------------
//
